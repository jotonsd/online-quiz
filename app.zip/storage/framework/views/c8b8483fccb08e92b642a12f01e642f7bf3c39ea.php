<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://bootswatch.com/5/flatly/bootstrap.css" rel="stylesheet">
    <link href="https://bootswatch.com/_vendor/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    

    <?php echo $__env->yieldContent('title'); ?>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <div>                
              <a class="navbar-brand" href="<?php echo e(route('dashboard.view')); ?>">Online Quiz</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
            </div>

            <div class="collapse navbar-collapse" id="navbarColor01">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::current()->uri == 'dashboard' ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.view')); ?>">Home</a>
                    </li>
                    <?php if(session('user_role')=='admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Route::current()->uri == 'add-quiz' ? 'active' : ''); ?>" href="<?php echo e(route('add.quiz')); ?>">Add Quiz</a>
                        </li>
                    <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Route::current()->uri == 'quiz-list' ? 'active' : ''); ?>" href="<?php echo e(route('list.quiz')); ?>">Quiz List </a>
                        </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::current()->uri == 'results' ? 'active' : ''); ?>" href="<?php echo e(route('results')); ?>">Results </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('logout')); ?>">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-3">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
              <strong><?php echo e(session('success')); ?></strong>
            </div>
        <?php endif; ?>
        <?php if(session('msg')): ?>

            <div class="alert alert-info">
              <strong><?php echo e(session('msg')); ?></strong>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
              <strong><?php echo e(session('error')); ?></strong>
            </div>
        <?php endif; ?>
        
        <?php echo $__env->yieldContent('main'); ?>
    </div>
<!-- Optional JavaScript; choose one of the two! -->

<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

</body>
</html>
<?php /**PATH C:\Users\DSL\Downloads\online-quiz-system-php-laravel-main\online-quiz-system-php-laravel-main\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>