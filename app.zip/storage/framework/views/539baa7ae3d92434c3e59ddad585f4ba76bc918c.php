<?php $__env->startSection('title'); ?>
    <title>Add Questions</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <h3>UPdate Question</h3>
    <div class="text-center mt-4">
        <div>
            <form method="post" action="<?php echo e(route('update.question',$data->id)); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group mt-2">
                    <input type="text" placeholder="Question" name="question" value="<?php echo e($data->question); ?>" required class="form-control">
                </div>
                <input type="hidden" name="quiz_id" value="<?php echo e($data->quiz_id); ?>" readonly required>
                <div class="form-group mt-2">
                    <input type="text" placeholder="Option A" name="option_a" value="<?php echo e($data->option_a); ?>" required class="form-control">
                </div>
                <div class="form-group mt-2">
                    <input type="text" placeholder="Option B" name="option_b" value="<?php echo e($data->option_b); ?>" required class="form-control">
                </div>
                <div class="form-group mt-2">
                    <input type="text" placeholder="Option C" name="option_c" value="<?php echo e($data->option_c); ?>" required class="form-control">
                </div>
                <div class="form-group mt-2">
                    <input type="text" placeholder="Option D" name="option_d" value="<?php echo e($data->option_d); ?>" required class="form-control">
                </div>
                <div class="form-group mt-2">
                    <select class="form-control" name="correct_option" required>
                        <option selected disabled value>-- Select Correct Option --</option>
                        <option value="option_a" <?php echo e($data->correct_option == "option_a" ? "selected" : ""); ?>>A</option>
                        <option value="option_b" <?php echo e($data->correct_option == "option_b" ? "selected" : ""); ?>>B</option>
                        <option value="option_c" <?php echo e($data->correct_option == "option_c" ? "selected" : ""); ?>>C</option>
                        <option value="option_d" <?php echo e($data->correct_option == "option_d" ? "selected" : ""); ?>>D</option>
                    </select>
                </div>
                <div class="text-center mt-2">
                    <button class="btn btn-primary" type="submit">Update</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Works(Joton)\Githubs\online-quiz\resources\views/admin/edit-question.blade.php ENDPATH**/ ?>