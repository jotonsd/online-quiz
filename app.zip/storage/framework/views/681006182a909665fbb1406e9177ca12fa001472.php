<?php $__env->startSection('title'); ?>
    <title>Quiz List</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <h3>Quiz List</h3>
    <div class="text-center mt-4">
        <table class="table table-bordered">
            <thead>
            <tr class="bg-primary text-white">
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">From</th>
                <th scope="col">To</th>
                <th scope="col">Duration</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $quiz_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($key++); ?></th>
                    <td><a style="text-decoration: none;" href="/add-question/<?php echo e($quiz->id); ?>" target="_blank"><?php echo e($quiz->title); ?></a></td>
                    <td><?php echo e($quiz->from_time); ?></td>
                    <td><?php echo e($quiz->to_time); ?></td>
                    <td><?php echo e($quiz->duration); ?> minutes</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DSL\Downloads\online-quiz-system-php-laravel-main\online-quiz-system-php-laravel-main\resources\views/admin/quiz-list.blade.php ENDPATH**/ ?>