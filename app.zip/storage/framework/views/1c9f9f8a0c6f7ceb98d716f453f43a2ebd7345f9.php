<?php $__env->startSection('title'); ?>
    <title>Inbox</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <h3>Inbox</h3>
    <div class="text-center mt-4">
        <table class="table table-bordered">
            <thead>
            <tr class="bg-primary text-white">
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Description</th>
                <th scope="col">Status</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e(++$key); ?></th>
                    <td><a href="<?php echo e(route('inbox_details', $item->id)); ?>"><?php echo e($item->name); ?></a></td>
                    <td><?php echo e($item->email); ?></td>
                    <td><?php echo e(substr($item->description, 0, 80)); ?></td>
                    <td><?php echo e($item->status == 0 ? 'Unseen' : 'Seen'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Works(Joton)\Githubs\online-quiz\resources\views/inbox.blade.php ENDPATH**/ ?>