<?php $__env->startSection('title'); ?>
    <title>Inbox Details</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <h3>Inbox Details</h3>
    <h4><?php echo e($data->name); ?></h4>
    <h4><?php echo e($data->email); ?></h4>
    <h5>Details:</h5>
    <p><?php echo e($data->description); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Works(Joton)\Githubs\online-quiz\resources\views/inbox-details.blade.php ENDPATH**/ ?>